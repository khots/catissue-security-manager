
package edu.wustl.common.datahandler;

public enum ParametersEnum 
{
	BUFFERSIZE, DELIMITER
};
