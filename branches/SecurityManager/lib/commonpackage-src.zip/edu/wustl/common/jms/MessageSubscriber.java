
package edu.wustl.common.jms;

/**
 *
 * @author kalpana_thakur
 * TODO This interface is used to initiate the connection.
 */
public interface MessageSubscriber
{

	/**
	 * This method is used to initialize the connection.
	 * */
	void initialize();
}
