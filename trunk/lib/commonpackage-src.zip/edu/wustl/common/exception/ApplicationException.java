
package edu.wustl.common.exception;

public  class ApplicationException extends Exception
{
	public ApplicationException(ErrorKey errorKey, Throwable t, String msgValues)
	{
		
	}
}
