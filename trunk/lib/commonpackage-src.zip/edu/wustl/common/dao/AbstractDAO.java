package edu.wustl.common.dao;

public class AbstractDAO {

}
