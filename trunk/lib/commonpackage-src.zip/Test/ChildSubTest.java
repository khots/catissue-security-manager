package Test;

import edu.wustl.common.beans.SessionDataBean;
import edu.wustl.common.dao.AbstractDAO;
import edu.wustl.common.security.exceptions.UserNotAuthorizedException;
import edu.wustl.common.util.dbmanager.DAOException;

public class ChildSubTest extends SubInheritanceTest{
	public boolean isAuthorized(AbstractDAO dao, Object domainObject,
			SessionDataBean sessionDataBean) throws UserNotAuthorizedException,
			DAOException {
		// TODO Auto-generated method stub
		return false;
	}
}
