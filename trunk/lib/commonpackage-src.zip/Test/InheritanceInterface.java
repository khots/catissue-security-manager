package Test;

import edu.wustl.common.beans.SessionDataBean;
import edu.wustl.common.dao.AbstractDAO;
import edu.wustl.common.security.exceptions.UserNotAuthorizedException;
import edu.wustl.common.util.dbmanager.DAOException;

public interface InheritanceInterface {
	public boolean isAuthorized(AbstractDAO dao, Object domainObject,
			SessionDataBean sessionDataBean) throws UserNotAuthorizedException, DAOException;
	
}
