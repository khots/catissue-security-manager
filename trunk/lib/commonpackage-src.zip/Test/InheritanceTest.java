package Test;

import edu.wustl.common.beans.SessionDataBean;
import edu.wustl.common.dao.AbstractDAO;
import edu.wustl.common.security.exceptions.UserNotAuthorizedException;
import edu.wustl.common.util.dbmanager.DAOException;

public abstract class InheritanceTest implements InheritanceInterface{
	public boolean isAuthorized(AbstractDAO dao, Object domainObject,
			SessionDataBean sessionDataBean) throws UserNotAuthorizedException,
			DAOException {
		// TODO Auto-generated method stub
		return false;
	}
	public static void main(String a[]) throws UserNotAuthorizedException, DAOException
	{
		InheritanceInterface g = new SubInheritanceTest();
		g.isAuthorized(null, null, null);
		g = new ChildSubTest();
		g.isAuthorized(null, null, null);
	}
}
